from .LottieLoader import LottieLoader


__all__ = [
    "LottieLoader",
]
